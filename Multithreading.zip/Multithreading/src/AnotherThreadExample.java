public class AnotherThreadExample extends Thread{

    public void run()
    {
        for(int i=10;i>=1;i--)
        {
            System.out.println("The value of i is : " + i);

            try{
                Thread.sleep(1000);
            }
            catch(Exception e)
            {

            }
        }
    }

    public static void main(String[] args) {
        ThreadExample1 t = new ThreadExample1();
        Thread th = new Thread(t);
        AnotherThreadExample a = new AnotherThreadExample();
        th.start();
        a.start();
    }
}
