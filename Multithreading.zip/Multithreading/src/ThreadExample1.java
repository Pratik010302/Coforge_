
// First Way of creating Thread

public class ThreadExample1 implements Runnable{

    public void run()
    {
        for(int i=1;i<=10;i++)
        {
            System.out.println("The value of i is : " + i);

            try{
                Thread.sleep(2000);
            }
            catch(Exception e){
            }
        }

    }

    public static void main(String[] args) {
        ThreadExample1 t = new ThreadExample1();
        Thread th = new Thread(t);
        th.start();
    }
}
