public class ThreadOpeartions {

    public static void main(String[] args) {

        int x = 56+96;
        System.out.println("Programme started...");
        System.out.println("The sum is  : " + x);


        Thread t = Thread.currentThread();
        String tname = t.getName();
        System.out.println("the current running thread is : " + tname);

        t.setName("MyNewThread");
        System.out.println("The new name of thread is : " + t.getName());
        try{
            Thread.sleep(5000);        }
        catch(Exception e)
        {

        }

        System.out.println("the Id of this thread is  : " + t.getId());
        System.out.println("Programme ended ...");

    }
}
