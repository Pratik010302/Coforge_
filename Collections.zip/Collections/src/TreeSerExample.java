import java.util.SortedSet;
import java.util.TreeSet;

public class TreeSerExample {

    public static void main(String[] args) {
        SortedSet<String> fruits= new TreeSet<>();
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Guava");
        fruits.add("Chiku");
        System.out.println("The original treeset is : " + fruits);
        // The duplicates are not allowed in this case matters
        fruits.add("Apple");
        // this will allow beacuse it is is lowercase
        fruits.add("banana");
        System.out.println(fruits);
    }
}
