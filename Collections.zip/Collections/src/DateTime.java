import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;

public class DateTime {
    public static void main(String[] args) {
        // 1. Printing current date without time
        LocalDate date = LocalDate.now();
        System.out.println("Current Date: " + date);

        // 2. Printing a specific date
        LocalDate specificDate = LocalDate.of(2024, Month.JUNE, 4);
        System.out.println("Specific Date: " + specificDate);

        // 3. Printing current time without date
        LocalTime time = LocalTime.now();
        System.out.println("Current Time: " + time);

        //4. Printing specific time
        LocalTime specifictime = LocalTime.of(13,45,30);
        System.out.println("Specific Time is: " + specifictime);

        //5. Printing date and time both
        LocalDateTime dateTime = LocalDateTime.now(); // Current date and time
        System.out.println(dateTime);
        LocalDateTime specificDateTime = LocalDateTime.of(2022, Month.JANUARY, 31, 13, 45, 30); // Specific date and time
        System.out.println(specificDateTime);

        //6. Manipulating date andd time is done by using methoda such as plus, Minus, with etc;

        LocalDate newdate = date.plusDays(1);
        System.out.println("the new date is : " + newdate);

        LocalTime newtime = time.plusHours(2).plusMinutes(34);
        System.out.println("The new time is : " + newtime);

    }
}
