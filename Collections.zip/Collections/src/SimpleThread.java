public class SimpleThread extends Thread {

    public void run() {
        for (int i = 1; i < 5; i++) {
            System.out.println("Inside run method");
        }
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            System.out.println("Thread interrupted");
        }
    }

    public static void main(String[] args) {
        SimpleThread s = new SimpleThread();
        s.start(); // Start the thread
    }
}
