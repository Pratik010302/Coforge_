public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello");
        String name1="Charan";
        String name2= "Krishna";
        String name3=name1;
        System.out.println(name1);
        System.out.println(name1.hashCode());
        System.out.println(name2);
        System.out.println(name2.hashCode());
        System.out.println(name3);
        System.out.println(name3.hashCode());

        name3=new String("Narayan");
        System.out.println(name3.hashCode());
        name1="Das";
        System.out.println(name1);
        System.out.println(name1.hashCode());
        name1="Shiv";
        System.out.println(name1.hashCode());
        StringBuffer name4=new StringBuffer("Swami");
        System.out.println("Before appending name4:" + name4);
        System.out.println(name4.hashCode());
        name4.append(name3);

        System.out.println("Before appending name4:"+ name4);
        System.out.println(name4.hashCode());
        StringBuffer sb=new StringBuffer();
        StringBuffer sb1=new StringBuffer(50);
        //sb1.append("Hello");
        sb1.insert(0,"This is a book");
        int n=sb1.indexOf("is");
        n=sb1.lastIndexOf("is");
        //sb1.reverse();
        System.out.println(sb1);
        sb1.insert(0,"Hello ");
        System.out.println(sb1);

        System.out.println("good Bye");
        StringBuilder str = new StringBuilder("Pratik");
        str.insert(6,"Hello");
        System.out.println(str);
        System.out.println(str.capacity());

        System.out.println("Great year ahead");
        StringBuilder s3=new StringBuilder();
        System.out.println(s3.capacity());
        s3.append("New York City");
        System.out.println(s3.capacity());
        s3.ensureCapacity(5);
        System.out.println(s3.capacity());






    }
}