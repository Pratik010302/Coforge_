import java.util.LinkedList;
import java.util.Queue;

public class QueueDemo {

    public static void main(String[] args) {
        Queue<String> queen = new LinkedList<>();
        queen.add("Pratik");
        queen.add("Pranav");
        queen.add("Sahil");
        queen.add("Rajesh");
        queen.add("Sarthak");
        System.out.println(queen);
        queen.remove();
        System.out.println(queen);
    }
}
