import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class Hashmap {

    public static void main(String[] args) {
        Map<String, Integer> numbermap = new HashMap<>();
        numbermap.put("One",1);
        numbermap.put("Two", 2);
        numbermap.put("Three",3);
        numbermap.put("Four",4);
        System.out.println(numbermap);

        Set <String> keys = numbermap.keySet();
        Collection<Integer> values = numbermap.values();
        Set<Entry<String, Integer>> entries = numbermap.entrySet();
        System.out.println("Keys from map : " + keys);
        System.out.println("Values  from map are  : " + values);
        System.out.println("Entryset from map is : " + entries);

    }
}
