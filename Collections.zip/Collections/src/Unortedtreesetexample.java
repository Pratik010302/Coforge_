import java.util.TreeSet;

public class Unortedtreesetexample {


    // This will not maintain order of elemets
    public static void main(String[] args) {
        TreeSet<String> myset = new TreeSet<>();
        myset.add("Maths");
        myset.add("Science");
        myset.add("History");

        System.out.println(myset);

    }
}
