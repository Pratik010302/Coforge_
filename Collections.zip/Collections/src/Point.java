public class Point implements Comparable<Point> {
    private int x;
    private int y;

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    @Override
    public int compareTo(Point other) {
        // First, compare x coordinates
        if (this.x != other.x) {
            return Integer.compare(this.x, other.x);
        }
        // If x coordinates are equal, compare y coordinates
        return Integer.compare(this.y, other.y);
    }

    public static void main(String[] args) {
        Point p1 = new Point(3, 4);
        Point p2 = new Point(2, 5);

        // Compare points
        int result = p1.compareTo(p2);
        if (result < 0) {
            System.out.println("p1 is less than p2");
        } else if (result > 0) {
            System.out.println("p1 is greater than p2");
        } else {
            System.out.println("p1 is equal to p2");
        }
    }
}