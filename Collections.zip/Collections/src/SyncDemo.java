class Counter {
    public synchronized void count(char[] chars) {
        for (char c : chars) {
            System.out.println( c);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}

public class SyncDemo extends Thread {
    Counter counter;
    char[] chars;

    public SyncDemo(Counter counter, char[] chars) {
        this.counter = counter;
        this.chars = chars;
    }

    public void run() {
        counter.count(chars);
    }

    public static void main(String[] args) {
        Counter counter1 = new Counter();

        char[] chars1 = {'H','E','L','L','O'};
        char[] chars2 = {'P','R','A','T','I','K'};

        SyncDemo syncDemo1 = new SyncDemo(counter1, chars1);
        SyncDemo syncDemo2 = new SyncDemo(counter1, chars2);

        syncDemo1.start();
        syncDemo2.start();
    }
}
