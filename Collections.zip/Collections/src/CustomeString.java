
import java.lang.*;

public class CustomeString {
    public static void main(String[] args) {
        System.out.println("Hello");

        java.lang.String name1 = "Charan";
        java.lang.String name2 = new java.lang.String("Krishna");
        java.lang.String name3 = name1;

        System.out.println(name1);
        System.out.println(name1.hashCode());
        System.out.println(name2);
        System.out.println(name2.hashCode());
        System.out.println(name3);
        System.out.println(name3.hashCode());

        name3 = new java.lang.String("Narayan");
        System.out.println(name3.hashCode());

        name1 = "Das";
        System.out.println(name1);
        System.out.println(name1.hashCode());

        name1 = "Shiv";
        System.out.println(name1.hashCode());

        StringBuffer name4 = new StringBuffer("Swami");
        System.out.println("Before appending name4: " + name4);
        System.out.println(name4.hashCode());

        name4.append(name3);
        System.out.println("After appending name4: " + name4);
        System.out.println(name4.hashCode());
    }
}
