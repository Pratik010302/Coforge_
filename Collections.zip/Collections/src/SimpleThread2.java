public class SimpleThread2 extends Thread{
    public void run() {
        for (int i = 1; i < 3; i++) {
            System.out.println(Thread.currentThread());//main,5,thread
            Thread.currentThread().setName("t1");
            Thread.currentThread().setPriority(7);
            System.out.println("Inside run method of SimpleThread class..."+Thread.currentThread());
            Thread.currentThread().setName("t2");
            Thread.currentThread().setPriority(8);
            System.out.println("Inside run method of SimpleThread class..."+Thread.currentThread());

            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }

    }

    public static void main(String[] args) {
        SimpleThread simpleThread=new SimpleThread();
        Thread thread1=new Thread(simpleThread);
        thread1.start();
        Thread thread2=new Thread(simpleThread);
        thread2.start();
    }
}