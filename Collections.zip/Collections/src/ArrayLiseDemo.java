import org.w3c.dom.ls.LSOutput;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ArrayLiseDemo {
    public static void main(String[] args) {
        ArrayList <String> data = new ArrayList<>();
        data.add("Kamal");
        data.add("Niti");
        data.add("Roshan");
        data.add(3,"Radha");
        data.add("Aman");
        data.add("Anita");
        //int x= print(67);
        List<String> result = data.stream()
                .filter(u -> u.startsWith("R"))
                .collect(Collectors.toList());
        System.out.println(result);


        List<Integer> lengths = data.stream()
                .map(String::length)
                .collect(Collectors.toList());
        System.out.println(lengths);

       /* for (int i = 0; i < data.size(); i++) {
            String str = data.get(i);
            System.out.println(str);*/
        String name="Narayan";
        System.out.println(name.length());


        List<String> flatmapresult = data.stream()
                .flatMap(s -> Arrays.stream(s.split("")))
                .collect(Collectors.toList());
        System.out.println(flatmapresult);

        List<String> sortedNames = data.stream()
                .sorted()
                .collect(Collectors.toList());
        System.out.println(sortedNames);


        List<String> distinctNames = data.stream()
                .distinct()
                .collect(Collectors.toList());
        System.out.println(distinctNames);

        List<String> limitedNames = data.stream()
                .limit(2)
                .collect(Collectors.toList());
        System.out.println(limitedNames);

        List<String> skippedNames = data.stream()
                .skip(1)
                .collect(Collectors.toList());
        System.out.println(skippedNames);

        // Terminal Operations

        List<String> collectedNames = data.stream().collect(Collectors.toList());
        System.out.println(collectedNames);

        // Terminal Operations

        // 1. converting into array
        Object[] array = data.stream().toArray();
        System.out.println("printing the arraylist in object array form");
        for(Object s: array) {
            System.out.println(s + " ");
        }

        // 2. count
        long count = data.stream().count();
        System.out.println("The length of the stream is :" + count);

        //3. anyMatch : Return sTrue or False as a result;
        boolean anyMatch = data.stream().anyMatch(myname -> myname.startsWith("J"));
        System.out.println(anyMatch);


        //4. allMatch(): Returns true if all elements matches the given predicate

        boolean allmatch = data.stream().allMatch(all -> all.endsWith(("s")));
        System.out.println(allmatch);

        //5. reduce
        List<Integer> list1 = new ArrayList<>();
        list1.add(30);
        list1.add(50);
        int sum = list1.stream().reduce(0,Integer::sum,  Integer::sum);
        System.out.println("The Sum of the list is :" + sum);

        //6..nonemaatch

        boolean nonematch = data.stream().noneMatch(nomatch -> nomatch.endsWith("j"));
        System.out.println(nonematch);


    }
}