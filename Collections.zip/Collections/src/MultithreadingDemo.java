class P {
    public void Pmethod() {
        for (int i = 1; i < 7; i++) {
            System.out.println("In Pmethod() " + i);
        }
    }
}

class Q {
    public void Qmethod() {
        for (int i = 1; i < 4; i++) {
            System.out.println("In Qmethod() " + i);
        }
    }
}

class R {
    public void Rmethod() {
        for (int i = 1; i < 5; i++) {
            System.out.println("In Rmethod() " + i);
        }
    }
}

public class MultithreadingDemo extends Thread {
    public void run() {
        System.out.println("Thread Started....");
        P pobj = new P();
        pobj.Pmethod();
        try {
            Thread.sleep(300);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        Q qobj = new Q();
        qobj.Qmethod();
        try {
            Thread.sleep(400);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        R robj = new R();
        robj.Rmethod();
        System.out.println("Thread Ended...");
    }

    public static void main(String[] args) {
        MultithreadingDemo multithreadingDemo1 = new MultithreadingDemo();
        MultithreadingDemo multithreadingDemo2 = new MultithreadingDemo();
        MultithreadingDemo multithreadingDemo3 = new MultithreadingDemo();

        Thread tobj1 = new Thread(multithreadingDemo1);
        Thread tob2 = new Thread(multithreadingDemo2);
        Thread tob3 = new Thread(multithreadingDemo3);

        // Set different priorities for each thread
        tobj1.setPriority(Thread.MIN_PRIORITY);  // Priority 1
        tob2.setPriority(Thread.NORM_PRIORITY);  // Priority 5 (default)
        tob3.setPriority(Thread.MAX_PRIORITY);   // Priority 10

        tobj1.start();
        tob2.start();
        tob3.start();

        // Wait for each thread to finish
        try {
            tobj1.join();
            tob2.join();
            tob3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("All threads have finished execution. Main thread is exiting.");
    }
}
