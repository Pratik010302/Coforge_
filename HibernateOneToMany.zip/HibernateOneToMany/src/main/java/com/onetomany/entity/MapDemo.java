package com.onetomany.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.ArrayList;
import java.util.List;

public class MapDemo {

    public static void main(String[] args) {
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        SessionFactory factory = cfg.buildSessionFactory();

        try (Session session = factory.openSession()) {
            Transaction tx = session.beginTransaction();

            Employee employee = new Employee();
            employee.setEmpid(101);
            employee.setEmail("abc12@gmail.com");
            employee.setFname("Pratik");
            employee.setLname("Wagh");

            Account account = new Account();
            account.setAccountNo("7628");
            account.setEmployee(employee);

            session.save(employee);
            session.save(account);

            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            factory.close();
        }
    }
}
