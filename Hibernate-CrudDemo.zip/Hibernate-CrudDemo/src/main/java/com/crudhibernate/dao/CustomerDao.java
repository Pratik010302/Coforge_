package com.crudhibernate.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.crudhibernate.model.Customer;
import com.crudhibernate.util.HBUtilClass;

public class CustomerDao {
	public void addCustomer(Customer Customer) {
        Transaction trns = null;
        Session session = HBUtilClass.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            session.save(Customer);
            session.getTransaction().commit();
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
    }
 
 //Read of CRUD
@SuppressWarnings("unchecked")
public List<Customer> getAllCustomers() {
        List<Customer> Customers = new ArrayList<Customer>();
        Session session = HBUtilClass.getSessionFactory().openSession();
        try {
            Customers = session.createQuery("from Customers").getResultList();
        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
        return Customers;
    }

//Read of CRUD
    public Customer getCustomerById(int Customerid) {
        Customer Customer = null;
        Session session = HBUtilClass.getSessionFactory().openSession();
        try {
            String hqlQuery = "from Customers where custId = :id";
            @SuppressWarnings("rawtypes")
            Query query = session.createQuery(hqlQuery);
            query.setParameter("custId", Customerid);
            Customer = (Customer) query.getSingleResult();
        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
        return Customer;
    }
   
  //Update of CRUD
    public void updateCustomer(Customer Customer) {
        Transaction trns = null;
        Session session = HBUtilClass.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            session.update(Customer);
            session.getTransaction().commit();
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
    }

    //Delete of CRUD
    public void deleteCustomer(int Customerid) {
        Transaction trns = null;
        Session session = HBUtilClass.getSessionFactory().openSession();
        try {
            trns = session.beginTransaction();
            Customer Customer = (Customer) session.load(Customer.class, new Integer(Customerid));
            session.delete(Customer);
            session.getTransaction().commit();
        } catch (RuntimeException e) {
            if (trns != null) {
                trns.rollback();
            }
            e.printStackTrace();
        } finally {
            session.flush();
            session.close();
        }
    }

}
