package com.crudhibernate.model;

import java.util.Date;

public class Customer {
	private int id;
    private String firstName;
    private String lastName;
    private Date dob;
    private String email;
	
   
	public Customer() {
		//super();
    	this.id=id;
    	this.firstName=firstName;
    	this.lastName=lastName;
    	this.dob=dob;
    	this.email=email;
    	
	}
	public void setId(int id) {
		this.id = id;
	}
    public int getId() {
		return id;
	}
    public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Date getDob() {
		return dob;
	}
	 public void setEmail(String email) {
			this.email = email;
		}
	public String getEmail() {
		return email;
	}
	
}
