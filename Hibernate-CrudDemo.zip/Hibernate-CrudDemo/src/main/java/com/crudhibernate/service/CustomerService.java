package com.crudhibernate.service;

import java.util.List;

import com.crudhibernate.dao.CustomerDao;
import com.crudhibernate.model.Customer;

public class CustomerService {
	private CustomerDao CustomerDao;

	public void addCustomer(Customer customer) {
		 CustomerDao.addCustomer(customer);
	}
	public List<Customer> getAllCustomers() {
		return CustomerDao.getAllCustomers();
	}

	//Read of CRUD
	    public Customer getCustomerById(int Customerid) {
	    	return CustomerDao.getCustomerById(Customerid);
	    }
	    
	  //Update of CRUD
	    public void updateCustomer(Customer customer) {
	    	CustomerDao.updateCustomer(customer);
	    }

	    //Delete of CRUD
	    public void deleteCustomer(int Customerid) {
	    	CustomerDao.deleteCustomer(Customerid);
	    }
	    public void setCustomerDao(CustomerDao CustomerDao) {
			this.CustomerDao = CustomerDao;
		}
		public CustomerDao getCustomerDao() {
			return CustomerDao;
		}

		
}
