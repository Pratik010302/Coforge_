package com.crudhibernate.client;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.crudhibernate.dao.CustomerDao;
import com.crudhibernate.model.Customer;
import com.crudhibernate.service.CustomerService;

public class CustomerClient {
	public static void main(String [] args) {
	CustomerService custservice = new CustomerService();
    CustomerDao custdao = new CustomerDao();
    custservice.setCustomerDao(custdao);
    Customer cust=new Customer();
    cust.setFirstName("Tisha");
    cust.setLastName("D'Souza");
    cust.setEmail("tdou@hmail.com");
    
    try {
        Date dob = new SimpleDateFormat("yyyy-MM-dd").parse("1995-01-01");
        cust.setDob(dob);
    } catch (ParseException ex) {
        ex.printStackTrace();
    }
   //cust.setEmail("john@sample.com");
    Customer Customer2 = new Customer();
    Customer2.setFirstName("Rushabh");
    Customer2.setLastName("Joshi");
    Customer2.setEmail("rs@gmail.com");
    try {
        Date dob = new SimpleDateFormat("yyyy-MM-dd").parse("1975-01-01");
        Customer2.setDob(dob);
    } catch (ParseException e) {
        e.printStackTrace();
    }
  //  Customer2.setEmail("robin@sample.com");
   
    custservice.addCustomer(cust);
    custservice.addCustomer(Customer2);

    // Get all Customers - Read of CRUD
    for (Customer rc1 : custservice.getAllCustomers()) {
        System.out.println(rc1.getFirstName());
        System.out.println(rc1.getLastName());
        System.out.println(rc1.getEmail());
        System.out.println(rc1.getDob());
    }
   /*
    // Get Customer by id - Read of CRUD
    Customer retrivedCustomer = custservice.getCustomerById(1);
    System.out.println(retrivedCustomer.getFirstName());
    System.out.println(retrivedCustomer.getLastName());
    System.out.println(retrivedCustomer.getEmail());
    System.out.println(retrivedCustomer.getDob());

    // Update Customer - Update of CRUD
    cust.setEmail("johnUpdated@sample.com");
    cust.setId(1);
    custservice.updateCustomer(cust);

    // Delete Customer - Delete of CRUD
    custservice.deleteCustomer(1);
*/
}
}