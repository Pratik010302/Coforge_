
// Prepared Statement : This Prepared statement interface is used for dynamic queries
// dynamic queries are the queries which take some parameters
// the values can be inserted in table at run time


import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.*;

public class InsertValue {
    public static void main(String[] args) {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");

            String url = "jdbc:mysql://localhost:3307/coforge";
            String username = "root";
            String password = "Pratik@123";

            Connection conn = DriverManager.getConnection(url, username, password);

            String q = "insert into student(sname) values(?)";
            PreparedStatement pstmt = conn.prepareStatement(q);

            Scanner sc = new Scanner(System.in);
            System.out.println("Enter name of student to insert in table...");
            String name = sc.nextLine();


            pstmt.setString(1,name);

            pstmt.executeUpdate();
            System.out.println("Values are inserted into student table...");

            conn.close();

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

}
