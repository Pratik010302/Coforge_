
import javax.xml.xpath.XPathEvaluationResult;
import java.sql.*;

public class SelectValue {
    public static void main(String[] args) {

        try{

            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3307/coforge";
            String username = "root";
            String password = "Pratik@123";

            Connection conn = DriverManager.getConnection(url,username,password);

            String q = "select * from student";

            Statement stmt = conn.createStatement();
            ResultSet set = stmt.executeQuery(q);

            while(set.next())
            {
                int id = set.getInt(1);
                String name = set.getString(2);
                System.out.println(id + " : " + name);
            }

            System.out.println("Data fetched Successfully...");

            conn.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
