
import java.io.*;
import java.sql.*;


public class ImageSave {
    public static void main(String[] args) {

        try{
            Class.forName("com.mysql.cj.jdbc.Driver");

            String url = "jdbc:mysql://localhost:3307/jdbc";
            String username = "root";
            String password = "Pratik@123";

            Connection conn = DriverManager.getConnection(url,username,password);

            String q = "insert into picture(image) value(?) ";

            PreparedStatement pstmt = conn.prepareStatement(q);

            FileInputStream fis = new FileInputStream("F:\\IIMAGES\\krishna.jpg");
            pstmt.setBinaryStream(1,fis,fis.available());

            pstmt.executeUpdate();

            System.out.println("Image inserted successfully...");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
