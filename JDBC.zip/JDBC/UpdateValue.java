
import java.io.*;
import java.sql.*;
import java.util.*;

public class UpdateValue {

    public static void main(String[] args) {
        try{

            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3307/coforge";
            String username = "root";
            String password = "Pratik@123";

            Connection conn = DriverManager.getConnection(url,username,password);

            String q = "update student set sname = ? where id = ?";

            Scanner sc = new Scanner(System.in);
            System.out.println("Enter id of student: ");
            int id = sc.nextInt();

            System.out.println("Enter new name of student : ");
            String name = sc.next();

           PreparedStatement pstmt = conn.prepareStatement(q);

           pstmt.setString(1,name);
           pstmt.setInt(2,id);

           pstmt.executeUpdate();

            System.out.println("Value updated successfully...");

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
