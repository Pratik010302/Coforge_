import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class FirstJDBC {
    public static void main(String[] args) {

        try {
            // 1. Load the driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2. Create a connection
            String url = "jdbc:mysql://localhost:3307/coforge";
            String username = "root";
            String password = "Pratik@123";

            Connection conn = DriverManager.getConnection(url, username, password);

            if (conn.isClosed()) {
                System.out.println("Connection is closed");
            } else {
                System.out.println("Connection is created...");
            }


           conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
