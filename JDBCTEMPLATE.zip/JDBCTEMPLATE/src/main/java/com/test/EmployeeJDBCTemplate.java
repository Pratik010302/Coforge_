package com.test;

import java.util.List;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeJDBCTemplate implements EmployeeDAO {
    private DataSource dataSource;
    private JdbcTemplate jdbcTemplateObject;

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
        this.jdbcTemplateObject = new JdbcTemplate(dataSource);
    }
    public void create(String empname, Integer pincode) {
        String SQL = "insert into Employee (empname, pincode) values (?, ?)";
        jdbcTemplateObject.update( SQL, empname, pincode);
        System.out.println("Created Data with Name = " + empname + " Pincode = " + pincode);
        return;   }
    public Employee getEmployee(Integer SID) {
        String SQL = "select * from Employee where SID = ?";
        Employee emp = jdbcTemplateObject.queryForObject(SQL,
                new Object[]{SID}, new EmployeeMapper());

        return emp;
    }
    public List<Employee> listEmployees() {
        String SQL = "select SID,EMPNAME,PINCODE from Employee";
        List <Employee> employees = jdbcTemplateObject.<Employee>query(SQL, new EmployeeMapper());
        List<Employee> employees1 = employees;
        return employees1;
    }
    public void delete(Integer SID) {
        String SQL = "delete from Employee where SID = ?";
        jdbcTemplateObject.update(SQL, SID);
        System.out.println("Deleted Data with ID = " + SID );
        return;
    }
    public void update(Integer SID, Integer pincode){
        String SQL = "update Employee set pincode = ? where SID = ?";
        jdbcTemplateObject.update(SQL, pincode, SID);
        System.out.println("Updated Data with ID = " + SID );
        return;
    }}
