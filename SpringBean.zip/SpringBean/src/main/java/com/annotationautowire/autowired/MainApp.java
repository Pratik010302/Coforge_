package com.annotationautowire.autowired;



import com.annotationautowire.required.Book;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.w3c.dom.Text;

public class MainApp {
    public static void main(String[] args) {
        ApplicationContext context = new
                ClassPathXmlApplicationContext("autowired.xml");
        TextEditor b1 = (TextEditor) context.getBean("textEditor");
        System.out.println( b1.getSpellChecker() );





    }
}

