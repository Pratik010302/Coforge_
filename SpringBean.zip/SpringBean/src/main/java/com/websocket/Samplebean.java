package com.websocket;

public class Samplebean {
    public Samplebean()
    {
        System.out.println("WebSocket Bean instance is created...");
    }
}
