package com.websocket;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainWebSocketApp {

    public static void main(String[] args) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
        ctx.register(WebSocketBeanConfig.class);
        ctx.refresh();

        com.websocket.Samplebean bean1 = ctx.getBean(com.websocket.Samplebean.class);
        System.out.println(bean1.hashCode());

        com.websocket.Samplebean bean2 = ctx.getBean(Samplebean.class);
        System.out.println(bean2.hashCode());
        ctx.close();
    }
}

