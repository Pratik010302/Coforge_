package com.postprocessor;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class TestMain {
    public static void main(String[] args) {
        ConfigurableApplicationContext context  = new ClassPathXmlApplicationContext("processor.xml");
        TestConnection networkMng = (TestConnection) context.getBean("connectionmanager");
        networkMng.readData();
        context.close();
    }}
