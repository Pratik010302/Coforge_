package com.prototype;

public class SampleBean{
    public SampleBean()
    {
        System.out.println("Prototype  Bean instance is created...");
    }
}
