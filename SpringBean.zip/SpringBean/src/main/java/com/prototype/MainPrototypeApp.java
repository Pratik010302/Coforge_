package com.prototype;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainPrototypeApp {

    public static void main(String[] args) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
        ctx.register(PrototypeBeanConfig.class);
        ctx.refresh();

        com.prototype.SampleBean bean1 = ctx.getBean(com.prototype.SampleBean.class);
        System.out.println(bean1.hashCode());

        com.prototype.SampleBean bean2 = ctx.getBean(SampleBean.class);
        System.out.println(bean2.hashCode());
        ctx.close();
    }
}

