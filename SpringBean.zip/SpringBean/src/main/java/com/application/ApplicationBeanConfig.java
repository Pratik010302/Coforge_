package com.application;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class ApplicationBeanConfig {

    @Bean
    @Scope(value="application")
    public SampleBean getBean()
    {
        return new SampleBean();
    }
}
