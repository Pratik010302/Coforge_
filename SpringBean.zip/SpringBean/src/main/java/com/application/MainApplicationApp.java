package com.application;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainApplicationApp {

    public static void main(String[] args) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
        ctx.register(ApplicationBeanConfig.class);
        ctx.refresh();

        SampleBean bean1 = ctx.getBean(SampleBean.class);
        System.out.println(bean1.hashCode());

        SampleBean bean2 = ctx.getBean(SampleBean.class);
        System.out.println(bean2.hashCode());
        ctx.close();
    }
}
