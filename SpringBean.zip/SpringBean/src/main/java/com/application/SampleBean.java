package com.application;

public class SampleBean {

    public SampleBean()
    {
        System.out.println("Application Bean instance is created... ");
    }
}
