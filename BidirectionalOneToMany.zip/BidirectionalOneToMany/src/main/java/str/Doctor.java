package str;

import java.util.Set;
public class Doctor {
    private int doctid;
    private String doctname;
    private Set patients;
    public int getDoctid() {
        return doctid;
    }
    public void setDoctid(int doctid) {
        this.doctid = doctid;
    }
    public String getDoctname() {
        return doctname;
    }
    public void setDoctname(String doctname) {
        this.doctname = doctname;
    }
    public Set getPatients() {
        return patients;
    }
    public void setPatients(Set patients) {
        this.patients = patients;
    }
}
