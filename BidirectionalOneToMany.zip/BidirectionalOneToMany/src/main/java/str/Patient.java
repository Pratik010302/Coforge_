package str;

public class Patient {
    private int patid;
    private String patname;
    private Doctor doctor;

    public String getPatname() {
        return patname;
    }
    public void setPatname(String patname) {
        this.patname = patname;
    }
    public int getPatid() {
        return patid;
    }
    public void setPatid(int patid) {
        this.patid = patid;
    }
    public Doctor getDoctor() {
        return doctor;
    }
    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }}
