package str;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {
    public static void main(String args[])
    {
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        SessionFactory factory = cfg.buildSessionFactory();
        Session session = factory.openSession();
        Doctor d =new Doctor();
        d.setDoctid(101);
        d.setDoctname("Mr. Srinivas");
        Patient p1=new Patient();
        p1.setPatid(10001);;
        p1.setPatname("Suman");
        Patient p2=new Patient();
        p2.setPatid(10002);;
        p2.setPatname("Sarika");
        Patient p3=new Patient();
        p3.setPatid(10003);;
        p3.setPatname("Nihar");
        // one-to-many
        Set s=new HashSet();
        s.add(p1);
        s.add(p2);
        s.add(p3);
        d.setPatients(s);
        // many-to-one

        p1.setDoctor(d);
        p2.setDoctor(d);
        p3.setDoctor(d);

        Transaction tx = session.beginTransaction();

        session.save(d);

        tx.commit();


        session.close();
        System.out.println("One To Many Bi-Directional is Done..!!");
        factory.close();

    }
}
