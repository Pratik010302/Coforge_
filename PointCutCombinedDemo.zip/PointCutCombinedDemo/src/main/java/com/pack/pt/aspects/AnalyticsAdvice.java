package com.pack.pt.aspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class AnalyticsAdvice {

    @Pointcut("within all dao(com.pack.pt.dat.*)")
    private void AllDao() {

    }
    // All update() methods
    @Pointcut("execution(* update(..))")
    private void updateMethod() {
    }

    //Special analytics for Update methods
    @Before("allDao() && updateMethod()")
    public void specialAnalytics(JoinPoint joinPoint) {
        System.out.println("Call special analytics for: "
                + joinPoint.getSignature());
    }

    //general analytics for other methods
    @Before("allDao() && !updateMethod()")
    public void generalAnalytics(JoinPoint joinPoint) {
        System.out.println("Call general analytics for:"
                + joinPoint.getSignature());
    }
}
