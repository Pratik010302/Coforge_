package com.pack.pt;

public class ApplicationConfig {
}
