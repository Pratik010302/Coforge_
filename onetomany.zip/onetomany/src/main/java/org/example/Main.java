package org.example;

import org.example.entity.Account;
import org.example.entity.Employee;
import org.example.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Main {
    public static void main(String[] args) {
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        Session session = null;

        try {
            session = sessionFactory.openSession();
            session.beginTransaction();

            Employee employee = new Employee();
            employee.setName("John Doe");

            Account account1 = new Account();
            account1.setType("Savings");

            Account account2 = new Account();
            account2.setType("Checking");

            employee.addAccount(account1);
            employee.addAccount(account2);

            session.save(employee);

            session.getTransaction().commit();
        } catch (Exception e) {
            if (session != null) {
                session.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
}
