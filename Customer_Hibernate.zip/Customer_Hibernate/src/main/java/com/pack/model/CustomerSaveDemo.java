package com.pack.model;


import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;

import com.pack.model.util.HbUtil;

public class CustomerSaveDemo {
    public static void main(String[] args) {
        Transaction transaction = null;
        try (Session session = HbUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            // Create and save customer objects
            Customer customer1 = new Customer();
            customer1.setFirstName("John");
            customer1.setLastName("Doe");
            customer1.setEmail("john.doe@example.com");

            Customer customer2 = new Customer();
            customer2.setFirstName("Jane");
            customer2.setLastName("Doe");
            customer2.setEmail("jane.doe@example.com");

            session.persist(customer1);
            session.persist(customer2);

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }

        try (Session session = HbUtil.getSessionFactory().openSession()) {
            List<Customer> customers = session.createQuery("from Customer", Customer.class).list();
            customers.forEach(c -> {
                System.out.println("Customer name: " + c.getFirstName() + " " + c.getLastName());
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
