package com.aop.snippets.enterprise;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.aop.snippets.enterprise.aop.DeBeforeMethod;
public class App {

    public static void main(String[] args) {

        ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        DemoSimpleService simpleService = (DemoSimpleService) context.getBean("simpleServiceProxy");
        simpleService.printSNameId();
        System.out.println("--------------");
        try{
            simpleService.checkSName();
        } catch(Exception e){
            System.out.println("SimpleService: Method checkName() exception thrown..");
        }

        context.close();
    }
}
